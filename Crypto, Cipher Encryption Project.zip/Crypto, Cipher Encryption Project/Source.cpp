// Cryptography
// 21st November, 2022
// 
// Goal: Convert Plaintext to MorseCode
// then reverse the outputted MorseCode.

#include <iostream>
using namespace std;

//Functions ------------------------------------------------------------------
    // Morse Code Dictionary
    string morseEncode(char x)
    {
        switch (x)
        {
        case 'a': return ".-";
        case 'b': return "-...";
        case 'c': return "-.-.";
        case 'd': return "-..";
        case 'e': return ".";
        case 'f': return "..-.";
        case 'g': return "--.";
        case 'h': return "....";
        case 'i': return "..";
        case 'j': return ".---";
        case 'k': return "-.-";
        case 'l': return ".-..";
        case 'm': return "--";
        case 'n': return "-.";
        case 'o': return "---";
        case 'p': return ".--.";
        case 'q': return "--.-";
        case 'r': return ".-.";
        case 's': return "...";
        case 't': return "-";
        case 'u': return "..-";
        case 'v': return "...-";
        case 'w': return ".--";
        case 'x': return "-..-";
        case 'y': return "-.--";
        case 'z': return "--..";
        case '1': return ".----";
        case '2': return "..---";
        case '3': return "...--";
        case '4': return "....-";
        case '5': return ".....";
        case '6': return "-....";
        case '7': return "--...";
        case '8': return "---..";
        case '9': return "----.";
        case '0': return "-----";

        default:
            cerr << "Found invalid character: " << x << ' '
                << std::endl;
            exit(0);
        }
    }
    void morseCode(string s)
    {
        // Character by character print
        // Morse code
        for (int i = 0; s[i]; i++)
            cout << morseEncode(s[i]);
        cout << endl;
    }
    string Reverse(string revVal)
    {
        if (revVal.length() == 1)
        {
            return revVal;
        }
        else
        {
            return Reverse(revVal.substr(1, revVal.length())) + revVal.at(0);
        }
    }

    // Main --------------------------------------------------------------------------
    int main()
    {
        string userInp;
        string* ptr = &userInp;

        //Prompt User.
        cout << "Welcome to Morse Encryption\n " << endl;

        cout << "Enter text to be encrypted: " << endl;
        cin >> userInp;
        cout << "\nEncrypting \"" << userInp << "\"" << endl;
        cout << endl << "Morse encryption: " << endl;

        //Encyption happens here
        morseCode(userInp);

        //Reversed Encryption
        cout << endl << "Reversed string:\n"
            << Reverse(userInp) << endl << endl;
        cout << "Morse Reversed: " << endl;

        //Update Pointer to Reversed Value
        *ptr = Reverse(userInp);

        //Morse Encryption for Reversed Value
        for (int i = 0; userInp[i]; i++)
            cout << morseEncode(userInp[i]);
        cout << endl;

        return 0;
    }